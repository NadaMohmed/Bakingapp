package com.example.ecommerce.popularmovies;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONException;

public class DetailsActivity extends AppCompatActivity {

    Movie movie ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        ImageView img = (ImageView)findViewById(R.id.imageView) ;
        TextView title = (TextView)findViewById(R.id.textView) ;
        TextView realse_date = (TextView)findViewById(R.id.textView2) ;
        TextView vote_average =(TextView)findViewById(R.id.textView3) ;
        TextView overview =(TextView) findViewById(R.id.textView4) ;


        Intent intent = getIntent() ;
        int position = intent.getIntExtra("position",0) ;
      JsonUtils json = new JsonUtils() ;
        String jsonresult = json.getTypeofmovie() ;
        Log.i("l",jsonresult) ;

        try {
            movie = json.getdeails(jsonresult,position);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Picasso.get().load(movie.getImageurl()).into(img);
        title.setText(movie.getTitle());
        realse_date.setText(movie.getRelesedate());
        vote_average.setText(movie.getVote_average());
        overview.setText(movie.getOverview());
    }
}
