package com.example.ecommerce.popularmovies;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils  {

   public static String typeofmovie ;

    public static void setTypeofmovie(String typeofmovie) {
        JsonUtils.typeofmovie = typeofmovie;
    }

    public static String getTypeofmovie() {
        return typeofmovie;
    }



    public static List<String> getimageurl(String json)
            throws JSONException {
        List<String>  imageresuls = new ArrayList<String>() ;

        JSONObject jsonObj = new JSONObject(json) ;

        //JSONObject variable = jsonObject.getJSONObject("results") ;
        JSONArray variable = jsonObj.getJSONArray("results") ;
        imageresuls.clear();
        for (int i=0 ; i<variable.length();i++)

        {
            JSONObject obj = variable.getJSONObject(i) ;
            imageresuls.add(obj.getString("poster_path")) ;

        }
        return imageresuls ;
    }

    public  Movie getdeails (String json ,int pos )
            throws JSONException
    {
        Movie movieobject ;
        JSONObject jsonObject = new JSONObject(json) ;
        JSONArray resultsarray = jsonObject.getJSONArray("results") ;
        JSONObject objectwithspecificposition= resultsarray.getJSONObject(pos) ;
        String title = objectwithspecificposition.getString("title");
        String releasedate = objectwithspecificposition.getString("release_date") ;
        String vote_average = String.valueOf( objectwithspecificposition.getDouble("vote_average")) ;
        String imageurl = "http://image.tmdb.org/t/p/" + "w185" +"/"+ objectwithspecificposition.getString("poster_path") ;
        String overview = objectwithspecificposition.getString("overview") ;
        movieobject = new Movie(title,releasedate,vote_average,imageurl,overview) ;
        return movieobject ;

    }

}
