package com.example.ecommerce.popularmovies;

public class Movie {
  private String title ;
    private String relesedate ;
    private String vote_average ;
    private String imageurl ;
    private String overview ;

public Movie(String title , String relesedate, String vote_average , String imageurl,String overview)
{
    this.title = title ;
    this.relesedate = relesedate ;
    this.vote_average = vote_average ;
    this.imageurl = imageurl ;
    this.overview = overview ;
}

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setRelesedate(String relesedate) {
        this.relesedate = relesedate;
    }

    public void setVote_average(String vote_average) {
        this.vote_average = vote_average;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getTitle() {
        return title;
    }

    public String getRelesedate() {
        return relesedate;
    }

    public String getVote_average() {
        return vote_average;
    }

    public String getImageurl() {
        return imageurl;
    }



}
