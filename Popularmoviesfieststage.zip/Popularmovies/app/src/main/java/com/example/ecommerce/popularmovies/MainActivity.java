package com.example.ecommerce.popularmovies;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    final static String baseurl = "http://image.tmdb.org/t/p/" ;
    final static String sizeofimage = "w185" ;
    String  jsonresultstring  ;
    TextView text ;
    URL resulturl ;
    List<String> imageresuls ;
    List<String> getpathofimageurl ;
    RecyclerView rv ;
    ImageGridAdapter iga ;
    // object to get json String
    JsonUtils jsonstring ;
    TextView errormessage ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jsonstring =  new JsonUtils() ;

     //errormessage= (TextView)findViewById(R.id.errormeassage) ;
        imageresuls = new ArrayList<String>() ;
        getpathofimageurl = new ArrayList<String>() ;
        text = (TextView)findViewById(R.id.text) ;
        // making grid view
        rv = findViewById(R.id.rv);

        resulturl = Networkutils.buildUrl() ;
        new GithubQueryTask().execute(resulturl);
     /*   StaggeredGridLayoutManager sglm = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        rv.setLayoutManager(sglm);*/



        /*try {
            imageresuls = JsonUtils.getimageurl(jsonresultstring) ;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        for (int i =0; i <imageresuls.size();i++)
        {

            text.append(imageresuls.get(i).toString());

        }*/


       // resulturl = Networkutils.buildUrl("popularity.desc") ;

        //String url = resulturl.toString() ;
        //new GithubQueryTask().execute(resulturl);

    }

  /* public void getjsonresultinstring ()
                     {
                         URL resulturl = Networkutils.buildUrl("popularity.desc") ;
                         new GithubQueryTask().execute(resulturl);


                      }*/

    public class GithubQueryTask extends AsyncTask<URL, Void, String> {

        // COMPLETED (2) Override the doInBackground method to perform the query. Return the results. (Hint: You've already written the code to perform the query)
        @Override
        protected String doInBackground(URL... params) {
            URL searchUrl = params[0];
            String githubSearchResults = null;
            try {
                githubSearchResults = Networkutils.getResponseFromHttpUrl(searchUrl);
                Log.i("msg",githubSearchResults) ;
            } catch (IOException e) {
                e.printStackTrace();
                Log.i("error",e.getMessage());
            }
            return githubSearchResults;
        }


        // COMPLETED (3) Override onPostExecute to display the results in the TextView
        @Override
        protected void onPostExecute(String githubSearchResults) {
            if (githubSearchResults != null && !githubSearchResults.equals("")) {
                jsonresultstring = githubSearchResults ;
                // bageb object el json 34an ab3ato lel function
                jsonstring.setTypeofmovie(githubSearchResults);

                // hanade hena 3la el function b3d ma postexecute tero7 w terga3 be el string malyan
                try {
                    imageresuls = JsonUtils.getimageurl(jsonresultstring) ;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                // bnade function ely betgebly rigth path lel image like http://image.tmdb.org/t/p/w185//nBNZadXqJSdt05SHLqgT0HuC5Gm.jpg
                getrightpathofimage(imageresuls);


                List<String> getpathofimageurlcopy = new ArrayList<String>(getpathofimageurl) ;
                // bnade 3la adapter 34an ygrbly data y7otaha fe grid view
                // iga = new ImageGridAdapter(MainActivity.this, getpathofimageurl);
                StaggeredGridLayoutManager sglm = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
                rv.setLayoutManager(sglm);

                iga = new ImageGridAdapter(MainActivity.this, getpathofimageurlcopy);
                 iga.notifyDataSetChanged();
                 rv.setAdapter(iga);

            }

            else
            {
                Toast.makeText(MainActivity.this, "Failed to get results,please try again", Toast.LENGTH_SHORT).show();

            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemThatWasClickedId = item.getItemId();
        if (itemThatWasClickedId == R.id.popularmovie) {
            //Toast.makeText(this, "popular movie", Toast.LENGTH_SHORT).show();
            resulturl = Networkutils.buildUrl() ;
            new GithubQueryTask().execute(resulturl);



            return true;
        }
        if (itemThatWasClickedId == R.id.topRatedMovie) {
            //Toast.makeText(this, "toprated movie", Toast.LENGTH_SHORT).show();
         //   resulturl = Networkutils.buildUrl("vote_average.desc") ;
            resulturl = Networkutils.buildUrlfortoprated();

            new GithubQueryTask().execute(resulturl);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    public void getrightpathofimage(List<String> imageresuls)
    {
        getpathofimageurl.clear();
        for (int i =0; i <imageresuls.size();i++)
        {
            String baseofimage ;

            baseofimage= baseurl+sizeofimage+"/"+ imageresuls.get(i).toString();
           getpathofimageurl.add(baseofimage);
           Log.i("ii",getpathofimageurl.get(i)) ;
            //   text.append(getpathofimageurl.get(i)+ "\n");
            //getpathofimageurl.add(i,baseofimage);
        }


    }
    /*public void addpolish ()
    {
        errormessage.setVisibility(View.VISIBLE);
        rv.setVisibility(View.INVISIBLE);

    }*/

}
